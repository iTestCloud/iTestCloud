/*
 * Copyright 2015-2026 the original author or authors.
 *
 * All rights reserved. This program and the accompanying materials are
 * made available under the terms of the Eclipse Public License v2.0 which
 * accompanies this distribution and is available at
 *
 * https://www.eclipse.org/legal/epl-v20.html
 */

/**
 * {@link org.junit.platform.engine.TestDescriptor}-related support classes
 * intended to be used by test engine implementations and clients of
 * the launcher.
 */

@NullMarked
package org.junit.platform.engine.support.descriptor;

import org.jspecify.annotations.NullMarked;
