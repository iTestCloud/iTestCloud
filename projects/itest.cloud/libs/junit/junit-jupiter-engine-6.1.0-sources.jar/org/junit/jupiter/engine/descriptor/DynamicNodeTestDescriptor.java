/*
 * Copyright 2015-2026 the original author or authors.
 *
 * All rights reserved. This program and the accompanying materials are
 * made available under the terms of the Eclipse Public License v2.0 which
 * accompanies this distribution and is available at
 *
 * https://www.eclipse.org/legal/epl-v20.html
 */

package org.junit.jupiter.engine.descriptor;

import java.util.Optional;
import java.util.OptionalInt;

import org.jspecify.annotations.Nullable;
import org.junit.jupiter.api.DynamicNode;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.engine.config.JupiterConfiguration;
import org.junit.jupiter.engine.execution.JupiterEngineExecutionContext;
import org.junit.platform.engine.TestDescriptor;
import org.junit.platform.engine.TestSource;
import org.junit.platform.engine.UniqueId;

/**
 * Base {@link TestDescriptor} for a {@link DynamicNode}.
 *
 * @since 5.0.3
 */
abstract class DynamicNodeTestDescriptor extends JupiterTestDescriptor {

	protected final int index;
	private final Optional<ExecutionMode> executionMode;

	DynamicNodeTestDescriptor(UniqueId uniqueId, int index, DynamicNode dynamicNode, @Nullable TestSource testSource,
			JupiterConfiguration configuration) {
		super(uniqueId, dynamicNode.getDisplayName(), testSource, configuration);
		this.index = index;
		this.executionMode = dynamicNode.getExecutionMode().map(JupiterTestDescriptor::toExecutionMode);
	}

	@Override
	Optional<ExecutionMode> getExplicitExecutionMode() {
		return executionMode;
	}

	@Override
	protected final String getLegacyReportingBaseName() {
		// @formatter:off
		return getParent()
				.map(it -> {
					if (it instanceof JupiterTestDescriptor parent) {
						return parent.getLegacyReportingBaseName();
					}
					return it.getLegacyReportingName();
				})
				.orElseGet(this::getDisplayName);
		// @formatter:on
	}

	@Override
	protected OptionalInt getLegacyReportingIndex() {
		return OptionalInt.of(index);
	}

	@Override
	public JupiterEngineExecutionContext prepare(JupiterEngineExecutionContext context) {
		ExtensionContext extensionContext = new DynamicExtensionContext(context.getExtensionContext(),
			context.getExecutionListener(), this, context.getConfiguration(), context.getExtensionRegistry(),
			context.getLauncherStoreFacade());
		// @formatter:off
		return context.extend()
				.withExtensionContext(extensionContext)
				.build();
		// @formatter:on
	}

	@Override
	public SkipResult shouldBeSkipped(JupiterEngineExecutionContext context) {
		return SkipResult.doNotSkip();
	}

}
